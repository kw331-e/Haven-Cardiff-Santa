extends CharacterBody2D

var speed = 400.0
var jump_velocity = -600.0 
var turn = 0.0
var lastPosX = 0
var movement = 0
var accelerating = false
var oscLeft = true

func _physics_process(delta: float) -> void:
	#region momentum handler
	turn = 0
	var moGain = [400, 414, 415, 429, 430, 444, 445, 458, 459, 471, 472, 485, 486, 498, 499, 510, 511, 522, 523, 534, 535, 545, 546, 556, 557, 567, 568, 578, 579, 588, 589, 598, 599, 608, 609, 617, 618, 627, 628, 636, 637, 645, 646, 654, 655, 662, 663, 671, 672, 679, 680, 688, 689, 696, 697, 704, 705, 712, 713, 719, 720, 727, 728, 735, 736, 742, 743, 749, 750, 757, 758, 764, 765, 771, 772, 778, 779, 785, 786, 792, 793, 798, 799, 805, 806, 812, 817, 823, 828, 834, 839, 844, 849, 855, 860, 865, 870, 875, 880, 885, 890, 894, 899, 904, 909, 913, 918, 923, 927, 932, 936, 941, 945, 950, 954, 958, 963, 967, 971, 976, 980, 984, 988, 993, 997, 1001]
	if position.x == lastPosX:
		movement = 0
	elif Input.is_action_pressed("ui_left") or Input.is_action_pressed("ui_right"):
		movement += 1
		accelerating = true
		lastPosX = position.x
	elif not accelerating:
		movement -= 2
	else:
		accelerating = false
	if movement < 0:
		movement = 0
	elif movement > 125:
		movement = 125
	speed = moGain[movement]
	
	turn = (movement+9)/10*0.02
	#endregion
	
	#region base check
	if not is_on_floor():
		velocity += get_gravity() * delta

	if Input.is_action_just_pressed("ui_up") and is_on_floor():
		velocity.y = jump_velocity

	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
	
	if (not (Input.is_action_pressed("ui_left") or Input.is_action_pressed("ui_right"))) and (movement > 0):
		if position.x < lastPosX:
			velocity.x = -speed
		else:
			velocity.x = speed
	#endregion
	#region spin physics
	if Input.is_action_pressed("ui_right") or Input.is_action_pressed("ui_nosedive"):
		oscLeft = false
	elif Input.is_action_pressed("ui_left") or Input.is_action_pressed("ui_bootit"):
		oscLeft = true
	if is_on_floor() and (Input.is_action_pressed("ui_left") or Input.is_action_pressed("ui_right")):
		turn += 0.1
	elif (Input.is_action_pressed("ui_nosedive") or Input.is_action_pressed("ui_bootit")):
		turn += 0.07
		if direction:
			turn += 0.075
	elif (Input.is_action_pressed("ui_left") or Input.is_action_pressed("ui_right")):
		turn += 0.05

	if oscLeft:
		turn *= -1
	rotation += turn
	#endregion
	
	move_and_slide()

func _recieve_pmove() -> void:
	if Input.is_action_pressed("ui_up"):
		#trigger animation here
		if velocity.x >= 0:
			velocity.x += 200
		else:
			velocity.x -= 200
		if velocity.y >= 0:
			velocity.y += 200
		else:
			velocity.y -= 200
		velocity.x *= -1
		velocity.y *= -1
