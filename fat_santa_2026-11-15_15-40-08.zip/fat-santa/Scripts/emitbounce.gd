extends TileMapLayer
signal trigger_pmove

func _on_chubs_body_entered(_body: Node2D) -> void:
	emit_signal("trigger_pmove")
